from django.contrib import admin
from Egzamin.models import Exam, UserAnswer, Question, Choice

admin.site.register(Exam)
admin.site.register(UserAnswer)
admin.site.register(Question)
admin.site.register(Choice)


# Register your models here.
