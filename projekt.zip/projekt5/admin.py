from django.contrib import admin
# from django.views import
from .models import Meeting

admin.site.register(Meeting)
# Register your models here.
