from django.apps import AppConfig


class Projekt5Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'projekt5'
