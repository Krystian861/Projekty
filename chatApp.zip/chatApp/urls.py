from django.urls import path
from . import views

urlpatterns = [
    path('index6', views.HomePage, name='/home4'),
    path('Chat/<str:room_name>/<str:username>/', views.MessageView, name='room'),
    path('delete_room/<str:room_name>/', views.delete_room, name='delete_room'),
    path('room/<str:room_name>/edit/', views.edit_room, name='edit_room')


]