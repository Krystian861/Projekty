from django.contrib import admin
from projekt.models import Egzamin, Kategoria

# Register your models here.

admin.site.register(Egzamin)
admin.site.register(Kategoria)
